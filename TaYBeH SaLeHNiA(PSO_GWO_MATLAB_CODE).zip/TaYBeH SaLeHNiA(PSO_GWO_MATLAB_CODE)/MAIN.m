%===========================================
% Matlab code for:
% 'MFO','AO','WOA','AOA','Firfly','GOA','HGWPSO','HHO','AVOA','PSO','GWO' Algorithms in:
% Multi-Level Image Thresholding Problem
% disp('MFO  ?  Moth Flame Optimization');
% disp('AO   ?  Aquila Optimizer');
% disp('WOA  ?  Whale Optimization Algorithm');
% disp('AOA  ?  Arithmetic Optimization Algorithm');
% disp('Firfly  ?  Firefly Algorithm');
% disp('GOA  ?  Grasshopper Optimization Algorithm');
% disp('HGWPSO  ?  Hybrid Grey Wolf with Particle Swarm Optimization');
% disp('HHO  ?  Harris Hawks Optimization');
% disp('AVOA  ?  African Vulture Optimization Algorithm');
% disp('PSO  ?  Particle Swarm Optimization');
% disp('GWO  ?  Grey Wolf Optimizer');
%===========================================
% Programmer : Taybeh Salehnia
% Email      : salehnia.taybeh@gmail.com
%===========================================
clc; 
clear all; 
close all;
%===========================================
disp('======================================');
disp('Programmer : Taybeh Salehnia');
disp('Email      : salehnia.taybeh@gmail.com');
disp('======================================');
%===========================================
disp('MFO  --  Moth Flame Optimization');
disp('AO   --  Aquila Optimizer');
disp('WOA  -- Whale Optimization Algorithm');
disp('AOA  -- Arithmetic Optimization Algorithm');
disp('Firfly  --  Firefly Algorithm');
disp('GOA  --  Grasshopper Optimization Algorithm');
disp('HGWPSO  --  Hybrid Grey Wolf with Particle Swarm Optimization');
disp('HHO  --  Harris Hawks Optimization');
disp('AVOA  --  African Vulture Optimization Algorithm');
disp('PSO  --  Particle Swarm Optimization');
disp('GWO  --  Grey Wolf Optimizer');
disp('======================================');
%==========================================================================
% Dataset
im = imread('Test1.tif'); % cameraman
% im = imread('Test2.tiff'); % Living Room
% im = imread('Test3.tiff'); % baboon
% im = imread('Test4.bmp'); % lena
% im = imread('Test5.bmp'); % airplane
% im = imread('Test6.png'); % peppers
% im = imread('Test7.png'); % bridge
% im = imread('Test8.jpg'); % lake
%==========================================================================
tic;
[~,~,c] = size(im);
if c>1
    im = rgb2gray(im);
end
im = double(im);

Histogram = imhist(uint8(im)) ./ numel(im);
Algorithms = {'MFO','AO','WOA','AOA','Firfly','GOA','HGWPSO','HHO','AVOA','PSO','GWO'};

Thresh_numbers = [2 3 4 5 6 7 8 9 10 16 32]; 
SearchAgents_no = 50;
Max_iter = 100;
time_initial = toc;
%==========================================================================
SegmentedImages = cell(length(Thresh_numbers), length(Algorithms));
for t = 1:length(Thresh_numbers)
    Thresh_number = Thresh_numbers(t);
    Class_number = Thresh_number + 1;
    dim = Thresh_number;
    maxI = max(im(:));
    minI = max(1,min(im(:)));
    lb = minI;
    ub = maxI;
    
    
    disp('-----------------------------Firfly-----------------------------');
    tic;
    [Best_Fit_Firfly, Best_Thresh_Firfly, Segment_im_Firfly] = Firfly_Segmentation(Histogram, im, Thresh_number, Class_number, SearchAgents_no, Max_iter, dim, maxI, minI, lb, ub);
    time_firfly = toc;
    Time_Firfly = time_initial + time_firfly;
    SegmentedImages{t,1} = Segment_im_Firfly;
    RMSE_Firfly = sqrt(sum((im(:)-Segment_im_Firfly(:)).^2)/numel(im));
    PSNR_Firfly = 20*log10(255/RMSE_Firfly);
    SSIM_Firfly = abs(ssim(im,Segment_im_Firfly,'RegularizationConstants',[6.5025,58.52252,29.2613]));
    SegmentBinary = imbinarize(uint8(Segment_im_Firfly));
    ImBinary = imbinarize(uint8(im));
    Accuracy_Firfly = sum(SegmentBinary(:)==ImBinary(:))/numel(im);
    STD_Firfly = std(Segment_im_Firfly(:));
    
    disp(['RMSE_Firfly: ', num2str(RMSE_Firfly)]);
    disp(['PSNR_Firfly: ', num2str(PSNR_Firfly)]);
    disp(['SSIM_Firfly: ', num2str(SSIM_Firfly)]);
    disp(['Accuracy_Firfly: ', num2str(Accuracy_Firfly)]);
    disp(['STD_Firfly: ', num2str(STD_Firfly)]);
    disp(['Time_Firfly: ', num2str(Time_Firfly)]);
    
    
    disp('-----------------------------GOA-----------------------------');
    tic;
    [Best_Fit_GOA, Best_Thresh_GOA, Segment_im_GOA] = GOA_Segmentation(Histogram, im, Thresh_number, Class_number, SearchAgents_no, Max_iter, dim, maxI, minI, lb, ub);
    time_goa = toc;
    Time_GOA = time_initial + time_goa;
    SegmentedImages{t,2} = Segment_im_GOA;
    RMSE_GOA = sqrt(sum((im(:)-Segment_im_GOA(:)).^2)/numel(im));
    PSNR_GOA = 20*log10(255/RMSE_GOA);
    SSIM_GOA = abs(ssim(im,Segment_im_GOA,'RegularizationConstants',[6.5025,58.52252,29.2613]));
    SegmentBinary = imbinarize(uint8(Segment_im_GOA));
    ImBinary = imbinarize(uint8(im));
    Accuracy_GOA = sum(SegmentBinary(:)==ImBinary(:))/numel(im);
    STD_GOA = std(Segment_im_GOA(:));
    
    disp(['RMSE_GOA: ', num2str(RMSE_GOA)]);
    disp(['PSNR_GOA: ', num2str(PSNR_GOA)]);
    disp(['SSIM_GOA: ', num2str(SSIM_GOA)]);
    disp(['Accuracy_GOA: ', num2str(Accuracy_GOA)]);
    disp(['STD_GOA: ', num2str(STD_GOA)]);
    disp(['Time_GOA: ', num2str(Time_GOA)]);
    
    
    disp('-----------------------------HGWPSO-----------------------------');
    tic;
    [Best_Fit_HGWPSO, Best_Thresh_HGWPSO, Segment_im_HGWPSO] = HGWPSO_Segmentation(Histogram, im, Thresh_number, Class_number, SearchAgents_no, Max_iter, dim, maxI, minI, lb, ub);
    time_hgw = toc;
    Time_HGWPSO = time_initial + time_hgw;
    SegmentedImages{t,3} = Segment_im_HGWPSO;
    RMSE_HGWPSO = sqrt(sum((im(:)-Segment_im_HGWPSO(:)).^2)/numel(im));
    PSNR_HGWPSO = 20*log10(255/RMSE_HGWPSO);
    SSIM_HGWPSO = abs(ssim(im,Segment_im_HGWPSO,'RegularizationConstants',[6.5025,58.52252,29.2613]));
    SegmentBinary = imbinarize(uint8(Segment_im_HGWPSO));
    ImBinary = imbinarize(uint8(im));
    Accuracy_HGWPSO = sum(SegmentBinary(:)==ImBinary(:))/numel(im);
    STD_HGWPSO = std(Segment_im_HGWPSO(:));
    
    disp(['RMSE_HGWPSO: ', num2str(RMSE_HGWPSO)]);
    disp(['PSNR_HGWPSO: ', num2str(PSNR_HGWPSO)]);
    disp(['SSIM_HGWPSO: ', num2str(SSIM_HGWPSO)]);
    disp(['Accuracy_HGWPSO: ', num2str(Accuracy_HGWPSO)]);
    disp(['STD_HGWPSO: ', num2str(STD_HGWPSO)]);
    disp(['Time_HGWPSO: ', num2str(Time_HGWPSO)]);
    
    
    disp('-----------------------------HHO-----------------------------');
    tic;
    [Best_Fit_HHO, Best_Thresh_HHO, Segment_im_HHO] = HHO_Segmentation(Histogram, im, Thresh_number, Class_number, SearchAgents_no, Max_iter, dim, maxI, minI, lb, ub);
    time_hho = toc;
    Time_HHO = time_initial + time_hho;
    SegmentedImages{t,4} = Segment_im_HHO;
    RMSE_HHO = sqrt(sum((im(:)-Segment_im_HHO(:)).^2)/numel(im));
    PSNR_HHO = 20*log10(255/RMSE_HHO);
    SSIM_HHO = abs(ssim(im,Segment_im_HHO,'RegularizationConstants',[6.5025,58.52252,29.2613]));
    SegmentBinary = imbinarize(uint8(Segment_im_HHO));
    ImBinary = imbinarize(uint8(im));
    Accuracy_HHO = sum(SegmentBinary(:)==ImBinary(:))/numel(im);
    STD_HHO = std(Segment_im_HHO(:));
    
    disp(['RMSE_HHO: ', num2str(RMSE_HHO)]);
    disp(['PSNR_HHO: ', num2str(PSNR_HHO)]);
    disp(['SSIM_HHO: ', num2str(SSIM_HHO)]);
    disp(['Accuracy_HHO: ', num2str(Accuracy_HHO)]);
    disp(['STD_HHO: ', num2str(STD_HHO)]);
    disp(['Time_HHO: ', num2str(Time_HHO)]);
    
    disp('-----------------------------MFO-----------------------------');
    tic;
    [Best_Fit_MFO, Best_Thresh_MFO, Segment_im_MFO] = MFO_Segmentation(Histogram, im, Thresh_number, Class_number, SearchAgents_no, Max_iter, dim, maxI, minI, lb, ub);
    time_mfo = toc;
    Time_MFO = time_initial + time_mfo;
    SegmentedImages{t,5} = Segment_im_MFO;
    RMSE_MFO = sqrt(sum((im(:)-Segment_im_MFO(:)).^2)/numel(im));
    PSNR_MFO = 20*log10(255/RMSE_MFO);
    SSIM_MFO = abs(ssim(im,Segment_im_MFO,'RegularizationConstants',[6.5025,58.52252,29.2613]));
    SegmentBinary = imbinarize(uint8(Segment_im_MFO));
    ImBinary = imbinarize(uint8(im));
    Accuracy_MFO = sum(SegmentBinary(:)==ImBinary(:))/numel(im);
    STD_MFO = std(Segment_im_MFO(:));
    
    disp(['RMSE_MFO: ', num2str(RMSE_MFO)]);
    disp(['PSNR_MFO: ', num2str(PSNR_MFO)]);
    disp(['SSIM_MFO: ', num2str(SSIM_MFO)]);
    disp(['Accuracy_MFO: ', num2str(Accuracy_MFO)]);
    disp(['STD_MFO: ', num2str(STD_MFO)]);
    disp(['Time_MFO: ', num2str(Time_MFO)]);

        
    disp('-----------------------------WOA-----------------------------');
    tic;
    [Best_Fit_WOA, Best_Thresh_WOA, Segment_im_WOA] = WOA_Segmentation(Histogram, im, Thresh_number, Class_number, SearchAgents_no, Max_iter, dim, maxI, minI, lb, ub);
    time_woa = toc;
    Time_WOA = time_initial + time_woa;
    SegmentedImages{t,6} = Segment_im_WOA;
    RMSE_WOA = sqrt(sum((im(:)-Segment_im_WOA(:)).^2)/numel(im));
    PSNR_WOA = 20*log10(255/RMSE_WOA);
    SSIM_WOA = abs(ssim(im,Segment_im_WOA,'RegularizationConstants',[6.5025,58.52252,29.2613]));
    SegmentBinary = imbinarize(uint8(Segment_im_WOA));
    ImBinary = imbinarize(uint8(im));
    Accuracy_WOA = sum(SegmentBinary(:)==ImBinary(:))/numel(im);
    STD_WOA = std(Segment_im_WOA(:));
    
    disp(['RMSE_WOA: ', num2str(RMSE_WOA)]);
    disp(['PSNR_WOA: ', num2str(PSNR_WOA)]);
    disp(['SSIM_WOA: ', num2str(SSIM_WOA)]);
    disp(['Accuracy_WOA: ', num2str(Accuracy_WOA)]);
    disp(['STD_WOA: ', num2str(STD_WOA)]);
    disp(['Time_WOA: ', num2str(Time_WOA)]);
    
    
    disp('-----------------------------AO-----------------------------');
    tic;
    [Best_Fit_AO, Best_Thresh_AO, Segment_im_AO] = AO_Segmentation(Histogram, im, Thresh_number, Class_number, SearchAgents_no, Max_iter, dim, maxI, minI, lb, ub);
    time_ao = toc;
    Time_AO = time_initial + time_ao;
    SegmentedImages{t,7} = Segment_im_AO;
    RMSE_AO = sqrt(sum((im(:)-Segment_im_AO(:)).^2)/numel(im));
    PSNR_AO = 20*log10(255/RMSE_AO);
    SSIM_AO = abs(ssim(im,Segment_im_AO,'RegularizationConstants',[6.5025,58.52252,29.2613]));
    SegmentBinary = imbinarize(uint8(Segment_im_AO));
    ImBinary = imbinarize(uint8(im));
    Accuracy_AO = sum(SegmentBinary(:)==ImBinary(:))/numel(im);
    STD_AO = std(Segment_im_AO(:));
    
    disp(['RMSE_AO: ', num2str(RMSE_AO)]);
    disp(['PSNR_AO: ', num2str(PSNR_AO)]);
    disp(['SSIM_AO: ', num2str(SSIM_AO)]);
    disp(['Accuracy_AO: ', num2str(Accuracy_AO)]);
    disp(['STD_AO: ', num2str(STD_AO)]);
    disp(['Time_AO: ', num2str(Time_AO)]);
    
    
    disp('-----------------------------AOA-----------------------------');
    tic;
    [Best_Fit_AOA, Best_Thresh_AOA, Segment_im_AOA] = AOA_Segmentation(Histogram, im, Thresh_number, Class_number, SearchAgents_no, Max_iter, dim, maxI, minI, lb, ub);
    time_aoa = toc;
    Time_AOA = time_initial + time_aoa;
    SegmentedImages{t,8} = Segment_im_AOA;
    RMSE_AOA = sqrt(sum((im(:)-Segment_im_AOA(:)).^2)/numel(im));
    PSNR_AOA = 20*log10(255/RMSE_AOA);
    SSIM_AOA = abs(ssim(im,Segment_im_AOA,'RegularizationConstants',[6.5025,58.52252,29.2613]));
    SegmentBinary = imbinarize(uint8(Segment_im_AOA));
    ImBinary = imbinarize(uint8(im));
    Accuracy_AOA = sum(SegmentBinary(:)==ImBinary(:))/numel(im);
    STD_AOA = std(Segment_im_AOA(:));
    
    disp(['RMSE_AOA: ', num2str(RMSE_AOA)]);
    disp(['PSNR_AOA: ', num2str(PSNR_AOA)]);
    disp(['SSIM_AOA: ', num2str(SSIM_AOA)]);
    disp(['Accuracy_AOA: ', num2str(Accuracy_AOA)]);
    disp(['STD_AOA: ', num2str(STD_AOA)]);
    disp(['Time_AOA: ', num2str(Time_AOA)]);
    
    
    disp('-----------------------------AVOA-----------------------------');
    tic;
    [Best_Fit_AVOA, Best_Thresh_AVOA, Segment_im_AVOA] = AVOA_Segmentation(Histogram, im, Thresh_number, Class_number, SearchAgents_no, Max_iter, dim, maxI, minI, lb, ub);
    time_avoa = toc;
    Time_AVOA = time_initial + time_avoa;
    SegmentedImages{t,9} = Segment_im_AVOA;
    RMSE_AVOA = sqrt(sum((im(:)-Segment_im_AVOA(:)).^2)/numel(im));
    PSNR_AVOA = 20*log10(255/RMSE_AVOA);
    SSIM_AVOA = abs(ssim(im,Segment_im_AVOA,'RegularizationConstants',[6.5025,58.52252,29.2613]));
    SegmentBinary = imbinarize(uint8(Segment_im_AVOA));
    ImBinary = imbinarize(uint8(im));
    Accuracy_AVOA = sum(SegmentBinary(:)==ImBinary(:))/numel(im);
    STD_AVOA = std(Segment_im_AVOA(:));
    
    disp(['RMSE_AVOA: ', num2str(RMSE_AVOA)]);
    disp(['PSNR_AVOA: ', num2str(PSNR_AVOA)]);
    disp(['SSIM_AVOA: ', num2str(SSIM_AVOA)]);
    disp(['Accuracy_AVOA: ', num2str(Accuracy_AVOA)]);
    disp(['STD_AVOA: ', num2str(STD_AVOA)]);
    disp(['Time_AVOA: ', num2str(Time_AVOA)]);
    
    
    disp('-----------------------------PSO-----------------------------');
    tic;
    [Best_Fit_PSO, Best_Thresh_PSO, Segment_im_PSO] = PSO_Segmentation(Histogram, im, Thresh_number, Class_number, SearchAgents_no, Max_iter, dim, maxI, minI, lb, ub);
    time_pso = toc;
    Time_PSO = time_initial + time_pso;
    SegmentedImages{t,10} = Segment_im_PSO;
    RMSE_PSO = sqrt(sum((im(:)-Segment_im_PSO(:)).^2)/numel(im));
    PSNR_PSO = 20*log10(255/RMSE_PSO);
    SSIM_PSO = abs(ssim(im,Segment_im_PSO,'RegularizationConstants',[6.5025,58.52252,29.2613]));
    SegmentBinary = imbinarize(uint8(Segment_im_PSO));
    ImBinary = imbinarize(uint8(im));
    Accuracy_PSO = sum(SegmentBinary(:)==ImBinary(:))/numel(im);
    STD_PSO = std(Segment_im_PSO(:));
    
    disp(['RMSE_PSO: ', num2str(RMSE_PSO)]);
    disp(['PSNR_PSO: ', num2str(PSNR_PSO)]);
    disp(['SSIM_PSO: ', num2str(SSIM_PSO)]);
    disp(['Accuracy_PSO: ', num2str(Accuracy_PSO)]);
    disp(['STD_PSO: ', num2str(STD_PSO)]);
    disp(['Time_PSO: ', num2str(Time_PSO)]);
    
    
    disp('-----------------------------GWO-----------------------------');
    tic;
    [Best_Fit_GWO, Best_Thresh_GWO, Segment_im_GWO] = GWO_Segmentation(Histogram, im, Thresh_number, Class_number, SearchAgents_no, Max_iter, dim, maxI, minI, lb, ub);
    time_gwo = toc;
    Time_GWO = time_initial + time_gwo;
    SegmentedImages{t,11} = Segment_im_GWO;
    RMSE_GWO = sqrt(sum((im(:)-Segment_im_GWO(:)).^2)/numel(im));
    PSNR_GWO = 20*log10(255/RMSE_GWO);
    SSIM_GWO = abs(ssim(im,Segment_im_GWO,'RegularizationConstants',[6.5025,58.52252,29.2613]));
    SegmentBinary = imbinarize(uint8(Segment_im_GWO));
    ImBinary = imbinarize(uint8(im));
    Accuracy_GWO = sum(SegmentBinary(:)==ImBinary(:))/numel(im);
    STD_GWO = std(Segment_im_GWO(:));
    
    disp(['RMSE_GWO: ', num2str(RMSE_GWO)]);
    disp(['PSNR_GWO: ', num2str(PSNR_GWO)]);
    disp(['SSIM_GWO: ', num2str(SSIM_GWO)]);
    disp(['Accuracy_GWO: ', num2str(Accuracy_GWO)]);
    disp(['STD_GWO: ', num2str(STD_GWO)]);
    disp(['Time_GWO: ', num2str(Time_GWO)]);
      
end % end of threshold loop
%% ======================================================================
figure('Name','Segmented Images - All Algorithms and Thresholds','NumberTitle','off');
for t = 1:length(Thresh_numbers)
    for a = 1:length(Algorithms)
        subplot(length(Thresh_numbers), length(Algorithms), (t-1)*length(Algorithms)+a);
        imshow(uint8(SegmentedImages{t,a}), []);
        if t==1
            title(Algorithms{a}, 'FontSize', 8);
        end
        if a==1
            ylabel(['T=', num2str(Thresh_numbers(t))], 'FontSize', 8);
        end
        axis off;
    end
end

