function [Best_Fit, Best_Thresh, Segment_im] = AO_Segmentation(Histogram, im, Thresh_number, Class_number, SearchAgents_no, Max_iter, Dim, CMax, minI, lb, ub)
% initialize position vector and score for the leader
Leader_pos=zeros(1,Dim);
Leader_score=inf; %change this to -inf for maximization problems
T=Max_iter;
Boundary_no= size(ub,2); % numnber of boundaries
Convergence_curve=zeros(1,Max_iter);
% If the boundaries of all variables are equal and user enter a signle
% number for both ub and lb
if Boundary_no==1
    Positions=rand(SearchAgents_no,Dim).*(ub-lb)+lb;
end

% If each variable has a different lb and ub
if Boundary_no>1
    for i=1:Dim
        ub_i=ub(i);
        lb_i=lb(i);
        Positions(:,i)=rand(SearchAgents_no,1).*(ub_i-lb_i)+lb_i;
    end
end
%==============================
%------------- AO ------------
%==============================
Best_P=zeros(1,Dim);
Best_FF=inf;
X=initialization(SearchAgents_no,Dim,ub,lb);
Xnew=X;
Ffun=zeros(1,size(X,1));
Ffun_new=zeros(1,size(Xnew,1));

t=1;
alpha=0.1;
delta=0.1;
    for i=1:size(X,1)
        F_UB=X(i,:)>ub;
        F_LB=X(i,:)<lb;
        X(i,:)=(X(i,:).*(~(F_UB+F_LB)))+ub.*F_UB+lb.*F_LB;
%         Ffun(1,i)=F_obj(X(i,:));
        fitness=fitnessfunction(X(i,:),Histogram,Thresh_number);
        if fitness<Best_FF
            Best_FF=fitness;
            Best_P=X(i,:);
        end
    end
    
while t<T+1
    
    G2=2*rand()-1; % Eq. (16)
    G1=2*(1-(t/T));  % Eq. (17)
    to = 1:Dim;
    u = .0265;
    r0 = 10;
    r = r0 +u*to;
    omega = .005;
    phi0 = 3*pi/2;
    phi = -omega*to+phi0;
    x = r .* sin(phi);  % Eq. (9)
    y = r .* cos(phi); % Eq. (10)
    QF=t^((2*rand()-1)/(1-T)^2); % Eq. (15)
        %-------------------------------------------------------------------------------------
    for i=1:size(X,1)
        if t<=(2/3)*T
            if rand <0.5
                Xnew(i,:)=Best_P(1,:)*(1-t/T)+(mean(X(i,:))-Best_P(1,:))*rand(); % Eq. (3) and Eq. (4)
            else
            %-------------------------------------------------------------------------------------
                Xnew(i,:)=Best_P(1,:).*Levy(Dim)+X((floor(SearchAgents_no*rand()+1)),:)+(y-x)*rand;       % Eq. (5)
            end
            %-------------------------------------------------------------------------------------
        else
            if rand<0.5
                Xnew(i,:)=(Best_P(1,:)-mean(X))*alpha-rand+((ub-lb)*rand+lb)*delta;   % Eq. (13)
            else
            %-------------------------------------------------------------------------------------
                Xnew(i,:)=QF*Best_P(1,:)-(G2*X(i,:)*rand)-G1.*Levy(Dim)+rand*G2; % Eq. (14)
            end
            %-------------------------------------------------------------------------------------
        end
                F_UB=Xnew(i,:)>ub;
                F_LB=Xnew(i,:)<lb;
                Xnew(i,:)=(Xnew(i,:).*(~(F_UB+F_LB)))+ub.*F_UB+lb.*F_LB;
%                 Ffun_new(1,i)=F_obj(Xnew(i,:));
                fitness=fitnessfunction(Xnew(i,:),Histogram,Thresh_number);
                if fitness<Ffun(1,i)
                    X(i,:)=Xnew(i,:);
                    Ffun(1,i)=fitness;
                end
                if Ffun(1,i)<Best_FF
                    Best_FF=Ffun(1,i);
                    Best_P=X(i,:);
                end
    end
    %-------------------------------------------------------------------------------------
    if mod(t,100)==0
        display(['At iteration ', num2str(t), ' the best solution fitness is ', num2str(Best_FF)]);
    end
    conv(t)=Best_FF;
    t=t+1;
    Convergence_curve(t)=Leader_score;
end



Best_Fit=1/Leader_score;
% Best_Fit=Leader_score;

Best_Thresh=floor(Best_P);
Best_Thresh=sort(Best_Thresh);

%==============================
%---- Evaluate Performance ----
%==============================
Segment_im=zeros(size(im));

for i=1:Class_number
    if i==1
        Segment_im(find(and(im<=(Best_Thresh(i)-1),im>=0)==1))=mean(im(find(and(im<=(Best_Thresh(i)-1),im>=0)==1)));
    elseif i>1 && i<Class_number
         Segment_im(find(and(im<=(Best_Thresh(i)-1),im>=Best_Thresh(i-1))==1))=mean(im(find(and(im<=(Best_Thresh(i)-1),im>=Best_Thresh(i-1))==1)));
    elseif i==Class_number
         Segment_im(find(and(im<=CMax,im>=Best_Thresh(i-1))==1))=mean(im(find(and(im<=CMax,im>=Best_Thresh(i-1))==1)));
    end
end

