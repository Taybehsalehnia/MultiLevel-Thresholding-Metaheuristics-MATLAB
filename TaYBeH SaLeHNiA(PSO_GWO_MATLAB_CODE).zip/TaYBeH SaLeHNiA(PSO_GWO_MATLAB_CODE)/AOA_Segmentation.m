function [Best_Fit, Best_Thresh, Segment_im] = AOA_Segmentation(Histogram, im, Thresh_number, Class_number, N, maxLoop, varNum, CMax, CMin, lowerBound, upperBound)
        
%==============================
%-------Initialization---------
%==============================
% initialize position vector and score for the leader
Rabbit_Pos=zeros(1,varNum);
Rabbit=inf; %change this to -inf for maximization problems

Boundary_no= size(upperBound,2); % numnber of boundaries

% If the boundaries of all variables are equal and user enter a signle number for both ub and lb
if Boundary_no==1
    Positions=rand(N, varNum).*(upperBound-lowerBound)+lowerBound;
end

% If each variable has a different lb and ub
if Boundary_no>1
    for i=1:varNum
        ub_i=upperBound(i);
        lb_i=lowerBound(i);
        Positions(:,i)=rand(N,1).*(ub_i-lb_i)+lb_i;
    end
end
%==============================
%------------- MPA ------------
%==============================

[Ave, Sd, Best_Fit, Best_Thresh, Segment_im]=AOA(im, CMax, N,maxLoop,lowerBound,upperBound, varNum, Histogram, Thresh_number, Class_number);
                                    
% display(['The average objective function is : ', num2str(Ave,7)]);
% display(['The standard deviation is : ', num2str(Sd,7)]);
