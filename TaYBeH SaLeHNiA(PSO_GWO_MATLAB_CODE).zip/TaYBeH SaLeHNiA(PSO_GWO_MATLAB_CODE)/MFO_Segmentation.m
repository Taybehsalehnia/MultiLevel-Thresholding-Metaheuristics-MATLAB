function [Best_Fit, Best_Thresh, Segment_im] = MFO_Segmentation(Histogram, im, Thresh_number, Class_number, N, Max_iter, dim, CMax, CMin, lb, ub)
%==============================
%-------Initialization---------
%==============================
%Initialize the positions of moths
Leader_pos=zeros(1,dim);
Leader_score=inf; %change this to -inf for maximization problems

Boundary_no= size(ub,2); % numnber of boundaries

% If the boundaries of all variables are equal and user enter a signle
% number for both ub and lb
if Boundary_no==1
    Moth_pos=rand(N,dim).*(ub-lb)+lb;
end

% If each variable has a different lb and ub
if Boundary_no>1
    for i=1:dim
        ub_i=ub(i);
        lb_i=lb(i);
        Moth_pos(:,i)=rand(N,1).*(ub_i-lb_i)+lb_i;
    end
end


%==============================
%------------- MFO ------------
%==============================
Convergence_curve=zeros(1,Max_iter);

Iteration=1;

% Main loop
while Iteration<Max_iter+1
    
    % Number of flames Eq. (3.14) in the paper
    Flame_no=round(N-Iteration*((N-1)/Max_iter));
    
    for i=1:size(Moth_pos,1)
        
        % Check if moths go out of the search spaceand bring it back
        Flag4ub=Moth_pos(i,:)>ub;
        Flag4lb=Moth_pos(i,:)<lb;
        Moth_pos(i,:)=(Moth_pos(i,:).*(~(Flag4ub+Flag4lb)))+ub.*Flag4ub+lb.*Flag4lb;  
        
        % Calculate the fitness of moths
        Moth_fitness(1,i)=fitnessfunction(Moth_pos(i,:),Histogram,Thresh_number);
        
        
    end
       
    if Iteration==1
        
        % Sort the first population of moths
        [fitness_sorted I] = sort(Moth_fitness);
        sorted_population = Moth_pos(I,:);
        
        % Update the flames
        best_flames=sorted_population;
        best_flame_fitness=fitness_sorted;
    else
        
        % Sort the moths
        double_population=[previous_population;best_flames];
        double_fitness=[previous_fitness best_flame_fitness];
        
        [double_fitness_sorted I]=sort(double_fitness);
        double_sorted_population=double_population(I,:);
        
        fitness_sorted=double_fitness_sorted(1:N);
        sorted_population=double_sorted_population(1:N,:);
        
        % Update the flames
        best_flames=sorted_population;
        best_flame_fitness=fitness_sorted;
    end
    
    % Update the position best flame obtained so far
    Best_flame_score=fitness_sorted(1);
    Best_flame_pos=sorted_population(1,:);
      
    previous_population=Moth_pos;
    previous_fitness=Moth_fitness;
    
    % a linearly dicreases from -1 to -2 to calculate t in Eq. (3.12)
    a=-1+Iteration*((-1)/Max_iter);
    
    for i=1:size(Moth_pos,1)
        
        for j=1:size(Moth_pos,2)
            if i<=Flame_no % Update the position of the moth with respect to its corresponsing flame
                
                % D in Eq. (3.13)
                distance_to_flame=abs(sorted_population(i,j)-Moth_pos(i,j));
                b=1;
                t=(a-1)*rand+1;
                
                % Eq. (3.12)
                Moth_pos(i,j)=distance_to_flame*exp(b.*t).*cos(t.*2*pi)+sorted_population(i,j);
            end
            
            if i>Flame_no % Upaate the position of the moth with respct to one flame
                
                % Eq. (3.13)
                distance_to_flame=abs(sorted_population(i,j)-Moth_pos(i,j));
                b=1;
                t=(a-1)*rand+1;
                
                % Eq. (3.12)
                Moth_pos(i,j)=distance_to_flame*exp(b.*t).*cos(t.*2*pi)+sorted_population(Flame_no,j);
            end
            
        end
        
    end
    
    Convergence_curve(Iteration)=Best_flame_score;
    
    % Display the iteration and best optimum obtained so far
%     if mod(Iteration,50)==0
%         display(['At iteration ', num2str(Iteration), ' the best fitness is ', num2str(Best_flame_score)]);
%     end
    Iteration=Iteration+1; 
end
Best_Fit=1/Best_flame_score;
% Best_Fit=Best_flame_score;

Best_Thresh=Best_flame_pos;
Best_Thresh=floor(sort(Best_Thresh));
%==============================
%---- Evaluate Performance ----
%==============================
Segment_im=zeros(size(im));

for i=1:Class_number
    if i==1
        Segment_im(find(and(im<=(Best_Thresh(i)-1),im>=0)==1))=mean(im(find(and(im<=(Best_Thresh(i)-1),im>=0)==1)));
    elseif i>1 && i<Class_number
         Segment_im(find(and(im<=(Best_Thresh(i)-1),im>=Best_Thresh(i-1))==1))=mean(im(find(and(im<=(Best_Thresh(i)-1),im>=Best_Thresh(i-1))==1)));
    elseif i==Class_number
         Segment_im(find(and(im<=CMax,im>=Best_Thresh(i-1))==1))=mean(im(find(and(im<=CMax,im>=Best_Thresh(i-1))==1)));
    end
end

