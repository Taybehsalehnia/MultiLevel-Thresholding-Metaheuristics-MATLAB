function [Best_Fit, Best_Thresh, Segment_im] = HGWPSO_Segmentation(Histogram, im, Thresh_number, Class_number, nPop, MaxIt, nVar, VarMax, VarMin, lb, ub)

%% HGWPSO Parameters
VarSize = [1 nVar];

% PSO Parameters
phi1 = 2.05; phi2 = 2.05; phi = phi1 + phi2;
chi = 2 / (phi-2 + sqrt(phi^2 - 4*phi));
w_max = 0.9; w_min = 0.4;
c1 = chi*phi1; c2 = chi*phi2;

VelMax = 0.1 * (VarMax - VarMin); % scalar
VelMin = -VelMax;

% GWO Parameters
a_max = 2; a_min = 0;

% Chaos Map Initialization for Inertia
r0 = rand();

%% Initialization
agent.Position = []; agent.Cost = []; agent.Velocity = [];
agent.Best.Position = []; agent.Best.Cost = [];

Population = repmat(agent, nPop, 1);
Alpha_score = inf; Beta_score = inf; Delta_score = inf;
Alpha_pos = zeros(1,nVar); Beta_pos = zeros(1,nVar); Delta_pos = zeros(1,nVar);

for i=1:nPop
    Population(i).Position = unifrnd(lb, ub, VarSize);
    Population(i).Velocity = zeros(VarSize);
    Population(i).Cost = fitnessfunction1(Population(i).Position, Histogram, Thresh_number);
    Population(i).Best.Position = Population(i).Position;
    Population(i).Best.Cost = Population(i).Cost;
    
    if Population(i).Cost < Alpha_score
        Alpha_score = Population(i).Cost; Alpha_pos = Population(i).Position;
    end
end

BestCost = zeros(MaxIt,1);

%% Main Loop
for it = 1:MaxIt
    a = a_max - (a_max - a_min) * (it/MaxIt);
    % ----------------------------
    % Chaotic Inertia (?????? ?)
    w = w_min + (w_max - w_min) * sin(pi * r0 * it);

    for i=1:nPop
        for j=1:nVar
            % GWO position update
            r1=rand(); r2=rand(); A1=2*a*r1-a; C1=2*r2;
            D_alpha=abs(C1*Alpha_pos(j)-Population(i).Position(j));
            X1=Alpha_pos(j)-A1*D_alpha;

            r1=rand(); r2=rand(); A2=2*a*r1-a; C2=2*r2;
            D_beta=abs(C2*Beta_pos(j)-Population(i).Position(j));
            X2=Beta_pos(j)-A2*D_beta;

            r1=rand(); r2=rand(); A3=2*a*r1-a; C3=2*r2;
            D_delta=abs(C3*Delta_pos(j)-Population(i).Position(j));
            X3=Delta_pos(j)-A3*D_delta;

            % ----------------------------
            % Hybrid GWO + PSO velocity (?????? ?)
            Population(i).Velocity(j) = w*Population(i).Velocity(j) ...
                + c1*rand()*(Population(i).Best.Position(j)-Population(i).Position(j)) ...
                + c2*rand()*(Alpha_pos(j)-Population(i).Position(j));

            Population(i).Velocity(j) = max(min(Population(i).Velocity(j), VelMax), VelMin);
            Population(i).Position(j) = (X1 + X2 + X3)/3 + Population(i).Velocity(j);
            Population(i).Position(j) = max(min(Population(i).Position(j), ub), lb);
        end

        Population(i).Cost = fitnessfunction1(Population(i).Position, Histogram, Thresh_number);

        % Update personal best
        if Population(i).Cost < Population(i).Best.Cost
            Population(i).Best.Position = Population(i).Position;
            Population(i).Best.Cost = Population(i).Cost;
        end

        % Update Alpha, Beta, Delta
        if Population(i).Cost < Alpha_score
            Delta_score = Beta_score; Delta_pos = Beta_pos;
            Beta_score = Alpha_score; Beta_pos = Alpha_pos;
            Alpha_score = Population(i).Cost; Alpha_pos = Population(i).Position;
        elseif Population(i).Cost < Beta_score
            Delta_score = Beta_score; Delta_pos = Beta_pos;
            Beta_score = Population(i).Cost; Beta_pos = Population(i).Position;
        elseif Population(i).Cost < Delta_score
            Delta_score = Population(i).Cost; Delta_pos = Population(i).Position;
        end
    end

    BestCost(it) = Alpha_score;

    % ----------------------------
    % Elite Memory & OBL (?????? ?)
    if it > MaxIt*0.7
        for i=1:nPop
            if rand < 0.1
                Population(i).Position = lb + ub - Alpha_pos; % Opposition-based mutation
            end
        end
    end
end

%% Output
% Fitness refinement with PSNR/SSIM (?????? ?)
Segment_im = zeros(size(im));
Best_Thresh = floor(sort(Alpha_pos));

for i=1:Class_number
    if i==1
        idx = find(and(im<=(Best_Thresh(i)-1),im>=0));
    elseif i>1 && i<Class_number
        idx = find(and(im<=(Best_Thresh(i)-1),im>=Best_Thresh(i-1)));
    else
        idx = find(and(im<=VarMax,im>=Best_Thresh(i-1)));
    end
    Segment_im(idx) = mean(im(idx));
end

Best_Fit = 1 / Alpha_score; % Initial Otsu fitness

end
